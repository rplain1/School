The code for Q1 and Q2 are in the same notebook. Additionally, Q2_kmeans.py is included that can be ran by specifying an image path. 

The code for Q3 is in a separate notebook Q3-Code notebook. 

The img directory contains images used in the final report. 